export class Customer {
  id!: number;
  firstname!: String;
  lastname!: String;
  dateOfBirth!:  String;
    phoneNumber!: String;
    email!: String;
  bankAccountNumber!: number;
}
