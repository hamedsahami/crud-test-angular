export class CustomerFilter {
  pageSize = 10;
  pageIndex = 1;
}
